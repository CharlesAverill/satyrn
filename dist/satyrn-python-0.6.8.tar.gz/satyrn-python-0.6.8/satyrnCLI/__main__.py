from .interpreter import start

if __name__ == "__main__":
    start()
