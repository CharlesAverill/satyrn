from .entry_point import main

__all__ = ["main"]
