Hosted page is at http://127.0.0.1:5000/

Sorry but I only added the setup files for Mac, it'll probably  work on other unix systems though. Just run `source setup.sh` for setup, and later you can use `source run.sh` to skip setup.

For Windows, here's setup:
```
> set FLASK_APP=satyrn_flask
> set FLASK_ENV=development
```
And use `flask run` to run.
