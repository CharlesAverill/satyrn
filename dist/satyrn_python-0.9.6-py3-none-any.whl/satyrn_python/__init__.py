"""Edit python code in a web IDE that supports backend multithreading and network collaboration."""
from .entry_point import main

__all__ = ["main"]
